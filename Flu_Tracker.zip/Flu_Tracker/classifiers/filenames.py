classifier_filename = "classifierCollection.pickle"
previous_classifier = "previousClassifierCollection.pickle"
documents_filename = "documents.pickle"
featureset_filename = "featuresets.pickle"
word_feature_filename = "word_features.pickle"
negative_tweets_filename = "negative.txt"
positive_tweets_filename = "positive.txt"

